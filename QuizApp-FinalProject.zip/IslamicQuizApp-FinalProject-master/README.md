# IslamicQuizApp-FinalProject

aplikasi berbasis android sederhana yang berisi tentang 5 pertanyaan seputar Islam dan diakhir sesi ada total skor yang ditampilkan.
silahkan jika ingin mengunduh source codenya untuk dipelajari.
semoga bermanfaat.
